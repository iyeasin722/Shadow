// ========== Firebase Storage আপলোড ফাংশন ==========

// ছবি আপলোড (Blaze plan এ কাজ করবে)
async function uploadImageToStorage(file, path) {
  if (!file) return null;
  
  try {
    const storageRef = firebase.storage().ref(path);
    const uploadTask = storageRef.put(file);
    
    return new Promise((resolve, reject) => {
      uploadTask.on('state_changed',
        (snapshot) => {
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log(`Upload progress: ${progress}%`);
        },
        (error) => {
          if (error.code === 'storage/unauthorized') {
            reject(new Error('Storage needs Blaze plan upgrade. Please upgrade in Firebase Console.'));
          } else {
            reject(error);
          }
        },
        async () => {
          const url = await storageRef.getDownloadURL();
          resolve(url);
        }
      );
    });
  } catch (e) {
    console.error("Upload error:", e);
    return null;
  }
}

// প্রোফাইল ছবি আপলোড
async function uploadProfileAvatar(file, userId) {
  const path = `avatars/${userId}/${Date.now()}_${file.name}`;
  return uploadImageToStorage(file, path);
}

// কভার ছবি আপলোড
async function uploadCoverImage(file, userId) {
  const path = `covers/${userId}/${Date.now()}_${file.name}`;
  return uploadImageToStorage(file, path);
}

// গল্পের কভার আপলোড
async function uploadStoryCover(file, userId, storyId) {
  const path = `story_covers/${userId}/${storyId}_${file.name}`;
  return uploadImageToStorage(file, path);
}

// ভিডিও আপলোড
async function uploadVideo(file, userId, storyId) {
  const path = `videos/${userId}/${storyId}_${file.name}`;
  return uploadImageToStorage(file, path);
}

// লোকাল স্টোরেজ ব্যাকআপ (Blaze plan না থাকলে)
function saveImageLocally(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = function(e) {
      resolve(e.target.result);
    };
    reader.readAsDataURL(file);
  });
}

// স্মার্ট আপলোড (Blaze plan চেক করে)
async function smartUpload(file, path, userId) {
  try {
    // প্রথমে Storage চেক করুন
    const isStorageReady = await window.checkStorageStatus();
    
    if (isStorageReady) {
      // Blaze plan active - Firebase Storage use করব
      return await uploadImageToStorage(file, path);
    } else {
      // লোকাল স্টোরেজ ব্যাকআপ
      console.log("📦 Using local storage fallback");
      return await saveImageLocally(file);
    }
  } catch (e) {
    console.error("Upload failed:", e);
    return await saveImageLocally(file);
  }
}

// ইমেজ ডিলিট
async function deleteImage(url) {
  if (!url) return;
  
  try {
    const storageRef = firebase.storage().refFromURL(url);
    await storageRef.delete();
    console.log("✅ Image deleted");
  } catch (e) {
    console.warn("Delete failed:", e);
  }
}

// গ্লোবাল এক্সপোর্ট
window.uploadImageToStorage = uploadImageToStorage;
window.uploadProfileAvatar = uploadProfileAvatar;
window.uploadCoverImage = uploadCoverImage;
window.uploadStoryCover = uploadStoryCover;
window.uploadVideo = uploadVideo;
window.smartUpload = smartUpload;
window.deleteImage = deleteImage;
window.saveImageLocally = saveImageLocally;

console.log("📦 Storage upload module ready (Blaze plan required for cloud storage)");